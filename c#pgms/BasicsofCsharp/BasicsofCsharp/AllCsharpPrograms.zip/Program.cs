﻿using BasicsofCsharp;

internal class Program
{
    public static void Main(string[] args)
    {
       // Console.WriteLine("Hello, World!");
       // add();
       // Operators.arithmeticOperator();
       // Operators.relationalOp();
       // Program op = new Program();
      //  op.Compare();
       // Console.WriteLine("Loops");
       // Loops.WhileLoop();
       // Loops.forLoop();
      //  Loops.ifWithBreak();
       // Loops.ifWithContinue();
        //Age.VoteEligible();
        SimpleInterest.simpleInterest();
       // PrintingTable.Table();
       // Conversion.milesTokilo();
       // Currency.cur();
       // Currency.cur1();



    }
    static void add()
    {
        int n1 = 10;
        float f2 = 10.00f;
        //long l3 = 10l;
        double d4 = 1000.00000;
        bool isActive = true;
        char chr = 'a';
        string suma = "c# programming";
        Console.WriteLine($"int value is: "+ n1);
        Console.WriteLine($"Float value is: { f2}");
       // Console.WriteLine($"Long Value is: {l3}");
        Console.WriteLine($"Double value is: {d4}");
        Console.WriteLine($"Boolean value is: {isActive}");
        Console.WriteLine($"Char value is: {chr}");
        Console.WriteLine($"String value is: {suma}");
        Console.WriteLine($"******************");
        Console.WriteLine("Implicit Conversion");
        Console.WriteLine($"******************");
        Implicitconversion();
        


    }
    static void Implicitconversion()
    {
        int n1 = 10;
        double d1 = n1;
        Console.WriteLine($"int n1 {n1} : double d1 {d1}");
        float f1 = 45.90f;
        double d2 = f1;
        Console.WriteLine($"Float f1 {f1} : double d2 {d2} ");
        Console.WriteLine($"******************");
        Console.WriteLine("ExplicitConversion Conversion");
        Console.WriteLine($"******************");
        ExplicitConversion();

    }
    static void ExplicitConversion()
    {
        double d1 = 24.67;
        int n1 = (int)d1;
        Console.WriteLine($"double d1 {d1} : int n1 {n1}");
        Console.WriteLine($"******************");
    }
    public void Compare()
    {
        int a = 20;
        int b = 40;
        Console.WriteLine(a== b);
        Console.WriteLine("a is not equal to b");
    
    }


}
