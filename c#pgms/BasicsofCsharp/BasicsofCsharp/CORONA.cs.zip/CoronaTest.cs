﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicsofCsharp
{
    internal class CoronaTest
    {
       
            public static void testMethod()
            {

                CoronaDashboard corona = new CoronaDashboard();
                corona.addCoronaData(1, "Maharashtra", 700, 1076, 6, 1780);
                corona.addCoronaData(2, "Kerala", 1000, 70, 10, 2000);
                corona.addCoronaData(3, "Karnataka", 500, 0, 6, 506);
                corona.addCoronaData(4, "Tamil Nadu", 4420, 1000, 6, 3000);
                corona.addCoronaData(5, "Andhra Pradesh", 1000, 1076, 6, 900);
                corona.listCoronaData();

            
            corona.updateCoronaData(6,"Jharkhand",1000,500,500,2000);
            Console.WriteLine("UPdating the corona data");
            corona.listCoronaData();
            //corona.info();
            corona.deleteCoronaData("Tamil Nadu");
            // corona.listCoronaData();

            corona.displayTopState();

            }

        
    }
}
