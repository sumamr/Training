﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace BasicsofCsharp
{
    internal class CoronaDashboard
    {
        public List<Corona> listname = new List<Corona>();
        public  void addCoronaData(int code, string name, int active, int recovered, int death, int total)
        {

            listname.Add(new Corona(code, name, active, recovered, death, total));
           
        }
       
        public  void updateCoronaData(int code, string name, int active, int recovered, int death, int total)
        {
            listname.Add(new Corona(code, name, active, recovered, death, total));

        }
        public  void deleteCoronaData(string name)
        {
            //listname.Add(new Corona(code, name, active, recovered, death, total));
            int del = -1;
            foreach(var s in listname)
            {
                if(s.name.Equals(name))
                {
                    del=listname.IndexOf(s);
                    break;
                }
                
            }
            listname.RemoveAt(del);

            Console.WriteLine("After Deleting the Corona Data");
            foreach(var s in listname)
            {
                Console.WriteLine(s.info());
            }

        }
        
        public void displayTopState()
        {
            int maxDeath = -1;
            foreach (var s in listname)
            {
                if (maxDeath < s.death)
                {
                    maxDeath =  s.death;
                }
            }
            Console.WriteLine("Top State in Corona Datalist according to death is : "+maxDeath);
            foreach(var s in listname)
            {
                if(maxDeath == s.death)
                Console.WriteLine(s.info());
            }
        }
        public  void listCoronaData()
        {
            foreach(var c in listname)
            {
                Console.WriteLine(c.info());
            }
        }
    }
    }

